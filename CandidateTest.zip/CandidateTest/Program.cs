﻿using Hoteliga.Channel.HotelAvailabilities.Responses.Reservations;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

namespace CandidateTest
{
    class Program
    {
        static void Main(string[] args)
        {
            // EXCERCISE #1
            // During deserialization there will be two exceptions
            // modify the Reservation class and all its associated classes accordingly 
            // so that the deserialization works without problems
            DeserializeReservation();

            // EXCERCISE #2
            // Implement ConvertBookerToCustomer as you feel fit to support the following cases
            // for name conversion. As you will see, in the Booker class, the name is one simple string
            // while in hoteliga there is a separation for first name and second name
            // the booker can be from one word to four words. Develop the logic as you see fit so that the method
            // ConvertBookerToCustomer is ready to handle from 1 to 4 words and throw exceptions for other cases
            var hoteligaCustomer1 = ConvertBookerToCustomer(new Booker { Name = "Dimitris van Leusden" });
            var hoteligaCustomer2 = ConvertBookerToCustomer(new Booker { Name = "Smith" });
            var hoteligaCustomer3 = ConvertBookerToCustomer(new Booker { Name = "John Smith" });
            var hoteligaCustomer4 = ConvertBookerToCustomer(new Booker { Name = "José Luis Rodríguez Zapatero" });

            // EXERCISE #3
            // currently the output of the method is 
            //  <Reservations xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
            //  <ReservationsList>
            //    <Reservation>
            //      <ReservationId>123</ReservationId>
            //      <LastName>van Leusden</LastName>
            //    </Reservation>
            //    <Reservation>
            //      <ReservationId>567</ReservationId>
            //      <LastName>Smith</LastName>
            //    </Reservation>
            //  </ReservationsList>
            //  </Reservations>
            // Adjust the code accordingly so that the output is:
            //  <Reservations>
            //    <Reservation id="123">
            //      <LastName>van Leusden</LastName>
            //    </Reservation>
            //    <Reservation id="567">
            //      <LastName>Smith</LastName>
            //    </Reservation>
            //  </Reservations>
            SerializeReservationsListToXml();
        }

        private static void DeserializeReservation()
        {
            var reservationsJson = File.ReadAllText("SampleReservation.json");
            var reservationsObject = JsonConvert.DeserializeObject<Hoteliga.Channel.HotelAvailabilities.Responses.Reservations.Reservation>(reservationsJson);
            Console.WriteLine("Successful deserialization");
        }

        private static Customer ConvertBookerToCustomer(Booker booker)
        {
            // TODO: Add implementation here
            return new Customer();
        }

        private static void SerializeReservationsListToXml()
        {
            var reservationsList = new Reservations
            {
                ReservationsList = new List<Reservation>
                {
                    new Reservation { ReservationId = "123", LastName = "van Leusden"},
                    new Reservation { ReservationId = "567", LastName = "Smith"}
                }
            };
            var xmlSerializer = new XmlSerializer(reservationsList.GetType());
            xmlSerializer.Serialize(Console.Out, reservationsList);
        }
    }

    public class Customer
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }

    public class Reservations
    {
        public List<Reservation> ReservationsList { get; set; }

        public Reservations()
        {
            ReservationsList = new List<Reservation>();
        }
    }

    public class Reservation
    {
        public string ReservationId { get; set; }
        public string LastName { get; set; }
    }
}